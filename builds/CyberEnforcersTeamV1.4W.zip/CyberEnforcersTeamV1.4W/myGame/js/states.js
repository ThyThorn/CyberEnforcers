// In your index.html, it should have the following:
/* <script type= "text/javascript" src = "phaser/myGame/js/title.js"> </script>
<script type= "text/javascript" src = "phaser/myGame/js/beginningDialog.js"> </script>
<script type= "text/javascript" src = "phaser/myGame/js/test.js"> </script>
<script type= "text/javascript" src = "phaser/myGame/js/testUnit.js"> </script>
<script type= "text/javascript" src = "phaser/myGame/js/states.js"> </script>*/

var game = new Phaser.Game(960, 600, Phaser.AUTO, '');
//game.state.add("title", title);
//game.state.add("beginningDialog", beginningDialogPlay);
game.state.add("level1Battle", level1Battle);
//game.state.start("title");
game.state.start("level1Battle");
