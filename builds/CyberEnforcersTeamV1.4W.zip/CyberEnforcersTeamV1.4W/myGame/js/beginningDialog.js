// Frame taken from plemuzic of opengameart.org.
// To do list: add dialog sprites and darkening of sprites to indicate which characters aren't speaking.

var beginningDialog = [
	"Kaito: My name is Kaito Ichiki.",
	"Kaito: I am a member of an organization called the Cybernetwork Enforcement\nand Regulation Commission.",
	"Kaito: It's pretty long, though, so we call it CERC for short.",
	"Kaito: We of CERC are in charge of maintaining the City's peace.",
	"Kaito: Years ago, mankind had at last made something truly awesome,\nafter years of research in computer networks.",
	"Kaito: There is now the Virtual World, which is a great advancement of the Internet.",
	"Kaito: Our lives had already involved the Internet a lot more,\nbut the Virtual World only marked that we should not stop there.",
	"Kaito: Thanks to the Virtual World, we don't even have to manually handle\nmuch of the technology in our daily lives. It's rather handy.",
	"Kaito: Of course, that comes with its downfalls. It makes it easier\nfor evildoers to work havoc.",
	"Kaito: Computer viruses and other cybernetic fiends still are these days.",
	"Kaito: And somehow, a few years ago, the monsters could at last\nmake their way from their virtual den to our real world!",
	"Kaito: Awful! They hurt many people, and by the time they were slain,\nmore had come to be in the Virtual World.",
	"Kaito: An easy way to deal with the problem would have been\nto delete the Virtual World, but...",
	"Kaito: It was far too much in our lives to get rid of. Very few would go through it.",
	"Kaito: Thus, the government thought of another solution. It established an agency\ndedicated to fighting the cybernetic creatures.",
	"Kaito: That's how CERC came to be. Now, life in Dennoshi City is rather peaceful,\nwith a virus attack every now and then.",
	"Kaito: Could be better, I guess. But I don't mind how things are in 2070.\nIt's a bit fun.",
	"Kaito: As for me, well...",
    "Atsumi: Kaito!",
    "Kaito: Wh-What's the problem?!",
    "Kaito: (This is Atsumi Ayukawa. She's also a member of CERC.)",
    "Kaito: (I myself am a commander of my own squad, Squad 667,\nso I'm technically the leader.)",
    "Kaito: (Of course, Atsumi's close to me, so she often treats me\nas if we were on equal terms.)",
    "Atsumi: The computer viruses! There's a report that they're coming out of\nthe Digital World in great numbers!",
    "Kaito: What?! How great is it?",
    "Atsumi: So great that they've spread throughout parts of the city in no time!",
    "Kaito: Oh no! We must go stop them!",
    "Junpei: Hey, Kaito, over here!",
    "Kaito: Junpei! What's the situation?",
    "Junpei: A group of viruses have gathered at those parts of the streets.",
    "Junpei: It's odd. There are far more of them than there usually are.",
    "Kaito: This must be some kind of outbreak, if you can even call it that.",
    "Kaito: (This is Junpei Kasuya. He's the third member of Squad 667, I being included.)",
    "Kaito: (He's a pretty friendly guy, and I trust him with the tasks I give him.)",
    "Kaito: (The thing is, he's a bit of a daredevil. Obedient he is not.)",
    "Junpei: Now's no time to talk about names, Kaito. We need to kill them quickly!",
    "Atsumi: Shouldn't we ask for orders from HQ first?",
    "Junpei: No time, Atsumi. Those damn viruses are terrorizing the city right now!",
    "Junpei: It's now or never, Kaito! And I say it's now, even if you disagree!",
    "Kaito: I'd ordinarily chide you for your lack of listening, but...",
    "Kaito: I find little reason to say otherwise. We'll attack them now.",
    "Atsumi: And I assume you'll be the one explaining this to HQ.",
    "Kaito: Don't I ever?",
    "???: If you're going to do that, let me analyze the situation first!",
    "Kaito: Kenta! About time you got here!",
    "Kenta: There was some problem I met along the way here, but I took care of it!",
    "Kaito: (Kenta is... a bit noteworthy.)",
    "Kaito: (Kenta looks human, but he's truly an AI that exists only in the Virtual World.",
    "Kaito: (The man who made him had him look like a young man.)",
    "Kaito: (The CERC gives every squad commander his own personal AI\nto help him with his duties.",
    "Kaito: (Kenta's useful and all, and he's considered our fourth member.)",
    "Kaito: (There are some parts of his... character that I would have changed\nhad I programmed him, though.)",
    "Kaito: Kenta, can you see what's going on on your side?",
    "Kenta: Let's see... Wow! Lots of viruses coming out from\nsome parts of the Virtual World.",
    "Kenta: A lot of them are leaking out into your world\nlike milk from a leaky carton!",
    "Kaito: Can you stop them on your end?",
    "Kenta: I can get rid of them easily, but things might get thorny\nif I let them get into your world.",
    "Kaito: Well, if that's so, let's be done with this quickly!"
];

var printedLine;

var lineVar = 1;
var bool;
var line;
var newLine;
var shake = true;
var introTheme;

var beginningDialogPlay = function(game) {};
beginningDialogPlay.prototype = {
    preload: function() {
        game.load.image('sky', 'phaser/myGame/assets/sky.png');
        game.load.image('textBox', 'phaser/myGame/assets/g4410.png');
        game.load.audio('introTheme', 'phaser/myGame/bgm/1. The Market.mp3');
    },

    create: function() {
        var sky = game.add.sprite(0, 0, 'sky');
        var textBox = game.add.sprite(0, game.world.height - 134, 'textBox');
        textBox.width = game.world.width;
        line = game.add.text(23,game.world.height - 120, "Kaito: My name is Kaito Ichiki.", {font: '18.4pt Georgia', fill: '#000' }); 
        // The string put in here is the first line that pops up.
        sky.scale.setTo(2, 1);
        introTheme = game.add.audio('introTheme');
        introTheme.loop = true;
        introTheme.play();
    },

    update: function() {
        if(lineVar == 3 && shake == true){
            game.camera.shake(0.05, 50);
            shake = false;
        }
    	if(game.input.keyboard.isDown(Phaser.Keyboard.ENTER)){
    		game.paused = true;
    	}
    	if(game.paused){
    		game.paused = false;
    		if(lineVar == beginningDialog.length) {
                lineVar = 0;
                line.destroy();
                game.sound.stopAll();
                game.state.start("level1Battle");
    		}
            shake = true;
    		newLine = beginningDialog[lineVar]
    		line.text = '' + newLine;
    		lineVar += 1;
    	}
    }   
}